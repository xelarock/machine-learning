# machine-learning
Projects for Emory CS 334 Machine Learning - Fall 2020

Homework 5

# THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS.
# Alex Welsh

Code is in pca.py and rf.py

PDF is HW5-CS334-Alex Welsh.pdf