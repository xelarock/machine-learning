# machine-learning
Projects for Emory CS 334 Machine Learning - Fall 2020

Homework 3

# THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS.
# Alex Welsh

Code is dt.py, q1.ipynb, q2.py, q3.ipynb

PDF is HW3-CS334-Alex Welsh.pdf