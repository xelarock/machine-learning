# machine-learning
Projects for Emory CS 334 Machine Learning - Fall 2020

Homework 3

# THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS.
# Alex Welsh

Code is selFeat.py, q1b.py, lr.py, standardLR.py, and sgdLR.py

PDF is HW3-CS334-Alex Welsh.pdf