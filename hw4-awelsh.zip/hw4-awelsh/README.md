# machine-learning
Projects for Emory CS 334 Machine Learning - Fall 2020

Homework 4

# THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS.
# Alex Welsh

Code is q1.py, perceptron.py, and q3.py

PDF is HW4-CS334-Alex Welsh.pdf