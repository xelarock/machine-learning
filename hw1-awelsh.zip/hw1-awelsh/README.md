# machine-learning
Projects for Emory CS 334 Machine Learning - Fall 2020

# THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY OTHER STUDENTS.
# Alex Welsh

Code is q1.py, q2.py, knn.py, q4.py

PDF is HW1-CS334-Alex Welsh.pdf